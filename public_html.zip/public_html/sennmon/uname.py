#!/usr/bin/python3.6
import cgi
import cgitb
import psycopg2
cgitb.enable()
connection = psycopg2.connect("host=localhost \
dbname=s2122090 user=s2122090 password=D8sxVHV5")
form = cgi.FieldStorage()
print("Content-Type: text/html")
print()
print('<html><head><title>円滑チャット掲示版</title></head>')
print('<body>')
print('<h1>円滑チャット掲示板</h1>')
print('<form action="./uname.py" method="POST">')
print('name: <input type="text" name="unames" size="40"><br />')
print('<input type="submit" value="送信!">')
print('</form>')
print('<form id="deleteForm" action="./uname.py" method="POST" onsubmit="event.preventDefault(); myFunction();">')
print('<input type="hidden" name="delete_all">')
print('<input type="submit" value="削除">')
print('</form>')

if "delete_all" in form:
    cur = connection.cursor()
    cur.execute("DELETE FROM uname;")
    connection.commit()
    cur.close()


if "unames" in form:
    unames=form["unames"].value
    cur = connection.cursor()
    cur.execute("insert into uname(unames) \
    values('%s');" % (unames))
    connection.commit()
    cur.close()

    print('<form action="./ideachat.py" method="POST">')
    print('<input type="submit" name="aggregate" value="会議に参加">')
    print('</form>')

print('<script>')
print('// ボタンがクリックされたときに実行する関数')
print('function myFunction() {')
print('  fetch(\'./uname.py\', {')
print('    method: \'POST\',')
print('    body: new FormData(document.getElementById(\'deleteForm\'))')
print('  })')
print('  .then(response => response.text())')
print('  .then(data => {')
print('    // レスポンス（テキスト）をページに表示')
print('    document.getElementById("demo").innerHTML = data;')
print('  });')
print('}')
print('</script>')



