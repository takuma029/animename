#!/usr/bin/python3.6
import cgi
import cgitb
cgitb.enable()
form = cgi.FieldStorage()
print("Content-Type: text/html")
print()
print('<html><head></head>')
print('<body>')
print('<form action="./sample2.py" method="POST">')
print(' 氏: <input type="text" name="ln">')
print(' 名: <input type="text" name="fn">')
print('<input type="submit">')
print('</form>')
if "fn" not in form or "ln" not in form:
    print("<p>氏名を入力してください。</p>")
else:
    fn=form["fn"].value
    ln=form["ln"].value
    print('<p>Hello, %s %s</P>' % (fn, ln))
print('</body></html')