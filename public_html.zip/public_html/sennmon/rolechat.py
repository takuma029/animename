#!/usr/bin/python3.6
import cgi
import cgitb
import psycopg2
cgitb.enable()
connection = psycopg2.connect("host=localhost \
dbname=s2122090 user=s2122090 password=D8sxVHV5")
form = cgi.FieldStorage()
print("Content-Type: text/html")
print()
print('<html><head><title>円滑チャット掲示版</title></head>')
print('<body>')
print('<h1>円滑チャット掲示板</h1>')
print('<form action="./rolechat.py" method="POST">')
print('role: <input type="text" name="message" size="40"><br />')
print('<input type="submit" value="post!">')
print('</form>')
print('<button onclick="window.location.href=\'https://muds.gdl.jp/~s2122090/sennmon/rolechat.py\'">更新</button>')
print('<br />')


import random

if "aggregate" in form:
    cur = connection.cursor()

    # rolechatテーブルから全ての列名を取得
    cur.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'rolechat'")
    columns = [column[0] for column in cur.fetchall() if column[0].startswith('role')]

    # 各messageに対して、登録されている全てのroleを表示
    cur.execute("SELECT DISTINCT message FROM rolechat")
    messages = cur.fetchall()

    # すでに選択されたroleを記録するリスト
    selected_roles = []

    for message in messages:
        roles = []
        for column in columns:
            cur.execute(f"SELECT {column} FROM rolechat WHERE message = %s", (message[0],))
            role = cur.fetchone()[0]
            if role is not None and role not in selected_roles:  # roleがNoneでなく、まだ選択されていない場合のみリストに追加
                roles.append(role)
        if roles:  # rolesが空でない場合のみ表示
            selected_role = random.choice(roles)
            selected_roles.append(selected_role)
            print(f"役割: {message[0]}, 担当: {selected_role}")
            print('<br />')


    cur.close()



print('<br />')
cur = connection.cursor()
cur.execute("SELECT message FROM ideachat ORDER BY value DESC LIMIT 1")
row = cur.fetchone()
if row is not None:
    print("最も評価が高いアイディア: %s" % row[0])
else:
    print("アイディアがありません")
cur.close()
print('<br />')
# if "aggregate" in form:
cur = connection.cursor()
cur.execute("SELECT message FROM howchat ORDER BY value DESC LIMIT 1")
row = cur.fetchone()
if row is not None:
    print("最も評価が高い方法: %s" % row[0])
else:
    print("方法がありません")
cur.close()

print('</body></html>')


if "message" in form:
    message=form["message"].value
    cur = connection.cursor()
    cur.execute("insert into rolechat(message,pdate) \
    values('%s',current_timestamp);" % (message))
    connection.commit()
    cur.close()

cur = connection.cursor()

# unameテーブルから全ての要素を取得
cur.execute("SELECT unames FROM uname")
unames = cur.fetchall()

# rolechatテーブルから全ての列名を取得
cur.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'rolechat'")
columns = cur.fetchall()

i = 0

# 各unameに対して、対応するrole列が存在するか確認し、存在しなければ追加
for i, uname in enumerate(unames, start=1):
    if ('role' + str(i),) not in columns:
        try:
            cur.execute(f"ALTER TABLE rolechat ADD COLUMN role{i} varchar(255);")
            connection.commit()
        except psycopg2.Error as e:
            print(f"Error adding column 'role{i}': {e}")
            continue

# 不要なrole列（unameの要素数を超えるもの）が存在する場合、削除
for j in range(i+1, len(columns)+1):
    if ('role' + str(j),) in columns:
        try:
            cur.execute(f"ALTER TABLE rolechat DROP COLUMN role{j};")
            connection.commit()
        except psycopg2.Error as e:
            print(f"Error dropping column 'role{j}': {e}")
            continue

cur.close()

# cur2 = connection.cursor()
cur = connection.cursor()
cur.execute("select cid,message,pdate from rolechat order by cid desc;")
# cur2.execute("SELECT COUNT(unames) FROM uname")
# rows = cur2.fetchone()  # 要素数を取得

print("<ul>")
for row in cur:
    cur3 = connection.cursor()
    cur3.execute("select unames from uname;")
    print("<li>")
    print("<button>%s (%s)</button>" % (row[1],row[2]))
    print('<div style="display: flex;">')
    print('<form action="./rolechat.py" method="POST">')
    print("<select name='rating'>")
    for row3 in cur3:
        print('<option value=%s> %s </option>' % (row3[0],row3[0]))
    print('</select>')
    print('<input type="hidden" name="cid" value="%s">' % row[0])  # cidをhiddenフィールドに設定
    print('<input type="submit" value="希望を送信">')
    print('</form>')
    print('<form id="deleteForm" action="./rolechat.py" method="POST" style="margin-left: 20px;">')  # 左マージンを追加
    print('<input type="hidden" name="delete_cid" value="%s">' % row[0])
    print('<input type="submit" value="削除">')
    print('</form>')
    print('</div>')  # divタグを閉じます

    print("</li>")
    cur3.close()

cur.close()
print("</ul>")

if "rating" in form and "cid" in form:
    rating = form["rating"].value  # 選択されたunameを取得
    cid = int(form["cid"].value)
    cur = connection.cursor()

    # unameテーブルから全ての要素を取得
    cur.execute("SELECT unames FROM uname")
    unames = cur.fetchall()

    # 各unameに対して、rolechatテーブルの対応するrole列に登録（既に登録されている場合はスキップ）
    for i, uname in enumerate(unames, start=1):
        cur.execute(f"SELECT role{i} FROM rolechat WHERE cid = %s", (cid,))
        role_value = cur.fetchone()[0]
        if role_value is None:
            if uname[0] == rating:
                cur.execute(f"UPDATE rolechat SET role{i} = %s WHERE cid = %s", (rating, cid))
                connection.commit()
                break

    cur.close()


    
if "delete_cid" in form:
    cid = int(form["delete_cid"].value)
    cur = connection.cursor()
    cur.execute("DELETE FROM rolechat WHERE cid = %s", (cid,))
    connection.commit()
    cur.close()

print('<script>')
print('document.getElementById(\'deleteForm\').addEventListener(\'submit\', function(event) {')
print('    event.preventDefault();')
print('    fetch(\'./rolechat.py\', {')
print('        method: \'POST\',')
print('        body: new FormData(event.target)')
print('    }).then(function() {')
print('        setTimeout(function(){ location.replace(location.href); }, 500);')  # 1秒後にページを更新
print('    });')
print('});')
print('</script>')

print('<form action="./rolechat.py" method="POST">')
print('<input type="submit" name="aggregate" value="集計">')
print('</form>')

print('</body></html>')