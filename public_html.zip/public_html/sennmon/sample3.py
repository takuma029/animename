#!/usr/bin/python3.6
import cgi
import cgitb
import psycopg2
cgitb.enable()
connection = psycopg2.connect("host=localhost \
dbname=s2122090 user=s2122090 password=D8sxVHV5")
form = cgi.FieldStorage()
print("Content-Type: text/html")
print()
print('<html><head></head>')
print('<body>')
print('<form action="./sample3.py" method="POST">')
print(' ユーザ名: <input type="text" name="uname"><br />')
print('message: <input type="text" name="message" size="40"><br />')
print('<input type="submit" value="chat!">')
print('</form>')
if "uname" in form and "message" in form:
    uname=form["uname"].value
    message=form["message"].value
    cur = connection.cursor()
    cur.execute("insert into pychat(uname,message,pdate) \
    values('%s','%s',current_timestamp);" % (uname, message))
    connection.commit()
    cur.close()
cur = connection.cursor()
cur.execute("select cid,uname,message,pdate from pychat order by cid desc;")
print("<ul>")
for row in cur:
    print("<li>%s: %s (%s)</li>" % (row[1],row[2],row[3]))
cur.close();
print("</ul>")
print('</body></html')