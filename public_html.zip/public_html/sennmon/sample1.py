#!/usr/bin/python3.6
import cgi
import cgitb
cgitb.enable()
print("Content-Type: text/html")
print()
print('<html><head></head>')
print('<body>')
print('<p>Hello, world.</p>')
print('</body></html>')