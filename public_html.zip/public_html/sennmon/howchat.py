#!/usr/bin/python3.6
import cgi
import cgitb
import psycopg2
cgitb.enable()
connection = psycopg2.connect("host=localhost \
dbname=s2122090 user=s2122090 password=D8sxVHV5")
form = cgi.FieldStorage()
print("Content-Type: text/html")
print()
print('<html><head><title>円滑チャット掲示版</title></head>')
print('<body>')
print('<h1>円滑チャット掲示板</h1>')
print('<form action="./howchat.py" method="POST">')
print('how: <input type="text" name="message" size="40"><br />')
print('<input type="submit" value="post!">')
print('</form>')
print('<button onclick="window.location.href=\'https://muds.gdl.jp/~s2122090/sennmon/howchat.py\'">更新</button>')
print('<br />')


# if "aggregate" in form:
cur = connection.cursor()
cur.execute("SELECT message FROM ideachat ORDER BY value DESC LIMIT 1")
row = cur.fetchone()
if row is not None:
    print("最も評価が高いアイディア: %s" % row[0])
else:
    print("アイディアがありません")
cur.close()

print('</body></html>')


if "message" in form:
    message=form["message"].value
    cur = connection.cursor()
    cur.execute("insert into howchat(message,pdate,value) \
    values('%s',current_timestamp,0);" % (message))
    connection.commit()
    cur.close()

cur = connection.cursor()
cur.execute("select cid,message,pdate,value from howchat order by cid desc;")
print("<ul>")
for row in cur:
    print("<li>")
    print("<button>%s (%s)</button>" % (row[1],row[2]))
    print('<div style="display: flex;">')
    print('<form action="./howchat.py" method="POST">')
    print("<select name='rating'>")
    print('<option value=1>星1</option>')
    print('<option value=2>星2</option>')
    print('<option value=3>星3</option>')
    print('<option value=4>星4</option>')
    print('<option value=5>星5</option>')
    print('</select>')
    print('<input type="hidden" name="cid" value="%s">' % row[0])
    print('<input type="submit" value="評価を送信">')
    print('</form>')
    print('<form id="deleteForm" action="./howchat.py" method="POST" style="margin-left: 20px;">')  # 左マージンを追加
    print('<input type="hidden" name="delete_cid" value="%s">' % row[0])
    print('<input type="submit" value="削除">')
    print('</form>')
    print('</div>')  # divタグを閉じます

    print("</li>")

cur.close()
print("</ul>")

if "rating" in form and "cid" in form:
    rating = int(form["rating"].value)
    cid = int(form["cid"].value)
    cur = connection.cursor()
    cur.execute("UPDATE howchat SET value = value + %s WHERE cid = %s", (rating, cid))
    connection.commit()
    cur.close()
    
if "delete_cid" in form:
    cid = int(form["delete_cid"].value)
    cur = connection.cursor()
    cur.execute("DELETE FROM howchat WHERE cid = %s", (cid,))
    connection.commit()
    cur.close()

print('<script>')
print('document.getElementById(\'deleteForm\').addEventListener(\'submit\', function(event) {')
print('    event.preventDefault();')
print('    fetch(\'./howchat.py\', {')
print('        method: \'POST\',')
print('        body: new FormData(event.target)')
print('    }).then(function() {')
print('        setTimeout(function(){ location.replace(location.href); }, 500);')  # 1秒後にページを更新
print('    });')
print('});')
print('</script>')



print('<form action="./rolechat.py" method="POST">')
print('<input type="submit" value="集計">')
print('</form>')

print('</body></html>')